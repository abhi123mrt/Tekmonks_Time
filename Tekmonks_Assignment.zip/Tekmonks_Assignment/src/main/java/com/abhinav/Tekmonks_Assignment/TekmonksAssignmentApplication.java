package com.abhinav.Tekmonks_Assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TekmonksAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(TekmonksAssignmentApplication.class, args);
	}

}
