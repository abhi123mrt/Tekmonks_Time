package com.abhinav.Tekmonks_Assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TekmonksAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
